# Axiom Intelligence · iPhone Edition 0.2

Installierbare **iPhone-Web-App (PWA)** für den persönlichen Solana-Analysten. Frontend 0.2, kompatibles Paper-only-Backend 0.1. Keine App-Store-App, keine IPA-Datei und keine Anmeldung mit Wallet-Schlüsseln.

## Was neu ist

- Untere Navigation mit Scanner, Setups, Positionen, Social und weiteren Bereichen.
- Token-Karten und Positionskarten statt breiter Desktop-Tabellen.
- Analyst als aufklappbares Panel, große Bedienelemente und Rücksicht auf Notch/Home-Indikator.
- Home-Bildschirm-Manifest, Apple-Touch-Icon und eigene Installationsseite unter `/install`.
- Wiederverbindung nach Standby, App-Wechsel und Netzwechsel. Paper-Aktionen bleiben bis zum Empfang frischer Daten gesperrt.
- Offline-Seite ohne alte Kurse. Private Markt-/Portfolio-/Orderdaten werden vom Service Worker nicht gespeichert.
- API-Token nur im Arbeitsspeicher; explizite Sitzungssperre. Keine Token-Parameter in URLs.
- Optionaler HTTPS-Einstieg mit Caddy und eigener Domain.

Die Sicherheitsprüfungen und Einschränkungen des Kernprojekts gelten weiter: unbekannte Pump-Event-Anhänge, fehlende Distribution oder veraltete Daten blockieren Einstiege. Reales Trading ist nicht implementiert. Ein positiver Ertrag ist nicht nachgewiesen.

## Bestehende Installation erweitern

Die Desktop-Version muss für die iPhone-Oberfläche **keinen zweiten Scanner** starten. Das neue Frontend verwendet dieselben API-Routen.

1. Vorhandene Konfiguration und Datenbank sichern.
2. Im bestehenden Projekt das Verzeichnis `frontend/` durch das neue `frontend/` ersetzen, einschließlich Dockerfile und `public/`. Für die Gateway-Cache-Header kann `infra/nginx.conf` übernommen werden.
3. Vorhandene `.env`, Datenbank-Volumes und den bisherigen Compose-Projektnamen beibehalten. **Keine neuen Passwörter für eine bestehende Datenbank erzeugen.**
4. Mit `docker compose up -d --build frontend gateway` das Frontend erneuern. Das Backend läuft weiter.
5. Für HTTPS entweder den vorhandenen TLS-Proxy verwenden oder die folgenden Caddy-Dateien und das Konfigurationsskript übernehmen.

Im bestehenden `.env` muss die tatsächlich verwendete HTTPS-Origin in `INTEL_ALLOWED_ORIGINS` stehen. Das neue Konfigurationsskript ergänzt sie, ohne API-/Datenbank-Geheimnisse zu ändern.

## Neu auf einem VPS installieren

Voraussetzungen: eigener Linux-Server mit Docker/Compose, eine eigene Domain bzw. Subdomain und gültige DNS-Einträge auf diesen Server. Die TCP-Ports 80 und 443 müssen erreichbar und frei sein. Eine fehlerhafte zusätzliche IPv6-Adresse im DNS verhindert gegebenenfalls die Zertifikatsausstellung.

```bash
unzip axiom-intelligence-iphone-v0.2.zip
cd axiom-intelligence-iphone
python3 scripts/configure.py
```

Danach in `.env` den eigenen Solana-RPC konfigurieren. Das öffentliche RPC reicht für Verbindungstests, bietet aber nicht zuverlässig alle Sicherheits-/Distribution-Abfragen.

Den folgenden Beispielnamen durch die **eigene echte Domain** ersetzen:

```bash
python3 scripts/iphone_https.py --domain intel.deine-domain.de
docker compose -f docker-compose.yml -f docker-compose.iphone.yml up --build -d
docker compose -f docker-compose.yml -f docker-compose.iphone.yml logs -f https
```

Caddy versucht für den eingetragenen öffentlichen DNS-Namen ein gültiges Zertifikat auszustellen. Das Skript konfiguriert nur die Adresse; es kauft keine Domain, ändert keine DNS-Einträge und bestätigt keine erfolgreiche TLS-Ausstellung.

Nach erfolgreichem Start auf dem iPhone **die eigene HTTPS-Adresse** in Safari öffnen. `localhost` auf dem iPhone zeigt auf das iPhone selbst und erreicht keinen VPS.

## Auf dem iPhone hinzufügen

1. Die eigene HTTPS-Adresse in **Safari** öffnen.
2. Im Seitenmenü **Teilen** auswählen; je nach Safari-Layout gibt es eine direkte Teilen-Taste.
3. **Zum Home-Bildschirm** auswählen und gegebenenfalls **Als Web-App öffnen** aktivieren.
4. **Hinzufügen** antippen und anschließend das neue Symbol öffnen.
5. Oben über das Einstellungssymbol oder über **Mehr → Verbindung & API** den eigenen `INTEL_API_TOKEN` aus `.env` eingeben und **Verbindung aktualisieren** wählen.

Der Token wird nicht dauerhaft gespeichert. Nach einem vollständigen App-Neustart kann eine erneute Eingabe notwendig sein. **Sitzung sperren** beendet die aktuelle Datenverbindung und entfernt den Token aus dem UI-Zustand.

## Verhalten im Alltag

- **App offen:** WebSocket-Snapshots im Ein-Sekunden-Ziel, REST-Fallback zum eigenen Backend.
- **App im Hintergrund / iPhone gesperrt:** iOS kann die Web-App pausieren. Der Scanner muss auf dem Rechner/VPS weiterlaufen.
- **Rückkehr:** alte Antworten aus der vorherigen Sitzung werden verworfen; Aktionen erst nach neuer Authentifizierung und frischer Backend-Auswertung.
- **Ohne Internet:** die öffentliche Offline-Seite erscheint, wenn der Service Worker zuvor erfolgreich installiert wurde. Es werden keine alten Trading-Daten als live präsentiert.
- **Alerts:** Audio nur bei geöffneter App und nach Nutzerinteraktion. Web Push ist nicht implementiert. Serverseitige Telegram-Alerts aus dem Kernprojekt sind optional separat konfigurierbar.
- **Manueller Stopp:** kann auch bei veralteter Analytik angefordert werden. Das Fortsetzen bleibt bis zu frischen Daten gesperrt; eine gesperrte Sitzung erlaubt keine Schreibzugriffe.
- **Orders:** ausschließlich Paper Trading. Ein Auftrag wird serverseitig erneut auf Datenalter, Signal, Limits und Idempotenz geprüft.

Ziel ist ein aktuelles iPhone/Safari. Die tatsächliche Darstellung und Home-Screen-Installation wurden in dieser Umgebung nicht auf einem physischen iPhone geprüft.

## Lokal entwickeln und prüfen

Der lokale Docker-Start bleibt unter http://localhost:8080 erreichbar:

```bash
python3 scripts/configure.py  # nur bei einer neuen Installation ohne .env
docker compose up --build -d
```

Für Python/Node ohne Docker gelten die Befehle aus [der Kernanleitung](docs/CORE_README_v0.1.md). Die aktuellen Frontend-Tests benötigen Node.js 24+:

```bash
cd frontend
npm ci
npm test
npm run typecheck
npm run build
npm run check:build
```

Backend-Tests: aus `backend/` mit installierten `requirements.lock` → `python -m pytest -q`.

## Weitere Dokumentation

- [iPhone-Auslieferungsprüfung](docs/VALIDATION.md)
- [Kernprojekt und vorhandene Funktionen](docs/CORE_README_v0.1.md)
- [Offizielle Schnittstellen / Research](docs/RESEARCH.md)
- [Kernarchitektur](docs/ARCHITECTURE.md)
- [Betrieb / Provider-Konfiguration](docs/OPERATIONS.md)
- [Scoring, Strategien und Risikolimits](docs/STRATEGIES.md)

Offizielle PWA-Grundlagen: [Apple – Website zum Home-Bildschirm hinzufügen](https://support.apple.com/en-gb/guide/iphone/iph42ab2f3a7/ios), [WebKit – Home-Screen-Web-Apps](https://webkit.org/blog/17333/webkit-features-in-safari-26-0/), [Next.js – PWA-Guide](https://nextjs.org/docs/app/guides/progressive-web-apps), [Caddy – Automatic HTTPS](https://caddyserver.com/docs/automatic-https).
