# Validierung · Auslieferungsstand v0.1

Prüfung am 2. November 2026 (Europe/Berlin). Ergebnis: ausführbarer erster Abschnitt mit tatsächlicher Datenanbindung; kein vollständiger professioneller Auto-Trading-Stack und kein Renditenachweis.

## Automatisiert

**49 Tests bestanden** auf Python 3.12.14. Erfasst sind unter anderem:

- Echtzeitfenster, Zukunftsdaten und Zeitgrenzen; Reihenfolge innerhalb gleicher Sekunden anhand von Slot/Event.
- Fehlende USD-Preise, keine optimistische Neugewichtung fehlender Score-Faktoren.
- Hinreichendes Momentum als qualifizierbarer Testfall; fehlende/alte Daten, Preisabweichung und unbekannte IDL-Anhänge als Blocker.
- Borsh-Längenbegrenzung, signierte `i128`-Reserven, falsche Herkunft, truncated logs, erfolgreiche vs. zurückgerollte CPI-Aufrufe.
- Öffentliche reale Mainnet-Fixtures einschließlich beobachteter Schemaabweichung.
- Mint Authority / Token-2022 / bekannte Vault-Ausschlüsse / Distribution-Ausfall.
- Kostenverlust bei unverändertem Preis, Größenlimits, gleichzeitige doppelte Orders, partielle Cost Basis, Trailing Exit.
- Neustart mit Position/Kill Switch/Idempotenz, Tages-/Drawdown-Blockade, DB-Schreibfehler ohne bestätigten Fill.
- HTTP-/WS-Authentifizierung, Origin-Prüfung, Contract-Validierung und fehlende Live-Orderroute.
- Durchgehender API-Test: qualifiziertes Testsignal → manuelle Paper-Order → idempotenter Retry → Kill Switch → erlaubter manueller Exit → blockierter neuer Einstieg.
- SQL-Collector-Lock, EVM-Reorg-Tombstone, Kandidaten-Eviction während asynchronem Commit.
- Causal Replay: keine späteren Preise/Quote-/Sicherheitsinformationen vor tatsächlicher Verfügbarkeit.

Zusätzlich wurden 421 tatsächlich aufgezeichnete Eingaben exportiert und durch die Replay-CLI verarbeitet. Es entstanden erwartungsgemäß keine Trades, keine Profit-Factor-/Win-Rate-Aussage und kein Renditenachweis.

Eine Starlette-TestClient-Abkündigungswarnung zu HTTPX bleibt sichtbar; sie ist kein fehlgeschlagener Test. Die produktive HTTPX-Anbindung wird dadurch nicht als getestet unterstellt.

## Frontend

- `npm run typecheck`: bestanden.
- Next.js 16.4.3 / React 19.3.1 Produktionsbuild: bestanden.
- TypeScript 5.9.3 wird absichtlich verwendet; der native TypeScript-7-Compiler konnte im eingeschränkten Prüfruntime seine Executable-Information aus `/proc` nicht lesen.
- Nur im Prüfruntime war eine externe Telemetrie-Kompatibilität nötig: gemessene V8-Heap-Werte und gemessene Peak-RSS statt nicht verfügbarer RSS-Systemabfrage. Diese Hilfsdatei ist **nicht** Teil des Projekts und verändert keine Anwendungs-/Trading-Logik. Auf dem Zielhost gelten die normalen Next-/Node-Startbefehle.
- **Browser-Sichtprüfung nicht durchgeführt:** Der bereitgestellte Managed-Preview-Daemon war nicht verfügbar. Responsive CSS, Tastaturfokus/Escape, Zustände und TypeScript wurden geprüft, aber kein visueller Browser-Test behauptet.

## Tatsächlicher Mainnet-Verbindungstest

Maschinenlesbare Ergebnisse: `docs/mainnet-smoke-final.json`. Der UTC-Zeitstempel 1. November 23:49 entspricht dem 2. November 00:49 in Berlin.

Konfiguration: öffentlicher Solana-RPC, Pump-only, maximal 40 Kandidaten, ca. 40 Sekunden Beobachtung.

| Messung | Beobachtet |
| --- | --- |
| Bestätigte normalisierte Trades | 397 |
| Verfolgte Tokens am Testende | 40 |
| Tatsächliche DEX-Screener-Marktsnapshots | 18 |
| Erhaltene Mint-Prüfergebnisse | 2 |
| Vollständige Distribution-Prüfungen | 0 |
| Queue-Drops in diesem Lauf | 0 |
| Decoderfehler in diesem Lauf | 0 |
| Interne Auswertung am Testende | ca. 7,23 ms |
| Freigegebene Entry-Kandidaten | 0 |
| Tokens mit Schema-Blockade | 40 |

Die Zählungen sind ein kurzer Verbindungstest, kein Lastbenchmark und keine 24/7-Zertifizierung. Gemeldete DEX-Liquidität ist keine bewiesene ausführbare Tiefe. Der öffentliche RPC konnte `getAccountInfo` beantworten; `getTokenLargestAccounts` lief im gesonderten Probeaufruf ins Zeitlimit. Der Code bewahrt partielle Mint-Befunde und erfindet keine Distribution.

Die empfohlenen offiziellen Pump-NPM-SDKs wurden zusätzlich geprüft und enthalten dieselben hier relevanten IDL-Endfelder. Der beobachtete zusätzliche Event-Anhang bleibt ungeklärt. Bekannte Daten werden angezeigt, Einstiege bleiben blockiert. Das ist eine reale aktuelle Einschränkung dieser Veröffentlichung.

Der öffentliche Robinhood-Mainnet-RPC antwortete auf `eth_chainId` mit **4663**. Mangels verifizierter DEX-Allowlist und eigener Provider-WS-Credentials wurde kein Robinhood-DEX-Handelsfluss vorgetäuscht.

## Nicht geprüft / noch offen

- Docker Compose wurde mangels Docker-Daemon in dieser Umgebung **nicht gestartet**. Dockerfiles/Compose und die gebauten Anwendungsartefakte liegen vor; der vollständige Containerstart ist auf dem Zielhost zu prüfen.
- PostgreSQL-/Redis-Laufzeitpfad und tatsächliche Robinhood-WS-Subscriptions sind nicht gegen persönliche produktive Provider getestet. SQLite, API und Paper-Pfad sind automatisiert geprüft.
- X-/Telegram-Collector wurden ohne persönliche API-Zugänge nicht gegen Accounts ausgeführt; es wurden keine Nachrichten versendet.
- Keine geschützte Axiom-API, keine Session, keine Wallet und kein Private Key wurden verwendet. Token-Deeplinks sind nicht belegt.
- Keine vollständige Solana-Reorg-Reconciliation, keine verlustfreie Queue und keine lückenlose Chain-/Wallet-Historie.
- Keine OOS-Renditestudie, kein historischer Marktbestand, keine MEV-/Failure-Kalibrierung und kein Profitabilitätsversprechen.

Für den nächsten Abschnitt müssen insbesondere Deployment-passende Pump-Schemas, ein geeigneter RPC-Vertrag mit Distribution-Zugriff und Quote-/Execution-Simulationen verifiziert werden. Erst danach können echte Entry-Schwellen sinnvoll anhand erhobener Daten geprüft werden.
