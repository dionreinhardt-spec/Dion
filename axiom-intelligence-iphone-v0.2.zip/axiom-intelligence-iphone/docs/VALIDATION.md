# iPhone Edition 0.2 · Auslieferungsprüfung

Stand: 2. November 2026, Europe/Berlin. Das ist eine installierbare PWA mit eigenem iPhone-Layout und dem Paper-only-Kernbackend. Es wurde keine native iOS-App signiert oder im App Store veröffentlicht.

## Ausgeführte Prüfungen

| Prüfung | Ergebnis |
| --- | --- |
| Backend und HTTPS-Konfiguration | **59 Tests bestanden** |
| Mobile Verbindung / Offline-Service-Worker | **20 Tests bestanden** |
| TypeScript | Bestanden |
| Next.js-Produktionsbuild | Bestanden |
| Generiertes PWA-Manifest / iPhone-Metadaten / PNG-Abmessungen | Geprüft durch `npm run check:build` |
| Safari auf physischem iPhone | Nicht durchgeführt |
| Visueller Browser-Test | Nicht durchgeführt: Managed-Preview-Daemon nicht verfügbar |
| Docker-/Caddy-TLS-Start gegen eine echte Domain | Nicht durchgeführt: kein Docker-Daemon bzw. kein persönlicher Domain-Zugang in dieser Umgebung |

Die 59 Backend-Tests enthalten die 49 Tests des Kernprojekts und zehn zusätzliche Fälle zur HTTPS-Origin-Konfiguration. Eine bestehende Starlette-TestClient-Abkündigungswarnung bleibt sichtbar; alle Assertions bestehen.

## Besondere iPhone-Schutzmechanismen

Die 20 mobilen Tests verwenden die tatsächlich in der App eingebundene Verbindungssteuerung und führen den tatsächlichen Service-Worker-Code in einer isolierten Testumgebung aus. Sie prüfen:

- Ohne neu empfangenen Snapshot keine Freigabe von Paper-Aktionen.
- Sofortige Sperre und Request-Abbruch bei Suspend; keine weiteren Reads im pausierten Zustand.
- Ignorieren verspäteter HTTP- und WebSocket-Callbacks einer alten Sitzung.
- Token ausschließlich als HTTP-Header und erstes WebSocket-Frame.
- Die zentrale Schreibregel blockiert Trades und das Fortsetzen automatischer Paper-Aktionen bei veralteten Daten. Ein manueller STOP bleibt auch bei veralteter Analytik erreichbar; Sitzungssperre, Vordergrund-/Netzwerkstatus und HTTPS gelten weiterhin.
- HTTP 401 und veraltete Backend-Auswertung geben Aktionen nicht frei.
- WebSocket-Ausfall bzw. fehlende Frames führen zu Sperre und REST-Fallback.
- Eine spätere REST-Antwort überschreibt keinen neueren WebSocket-Stand.
- Wiederholte identische Snapshots halten den Client nicht unbegrenzt „frisch“.
- Ungültige WebSocket-Pakete sperren Aktionen.
- Private API-, Portfolio-, Order-, Health- und WebSocket-Pfade werden vom Service Worker weder abgefangen noch gecacht.
- Offline-Navigation liefert ausschließlich die öffentliche Offline-Seite.
- Normale Navigation nutzt das Netzwerk; fremde Origins bleiben unberührt.
- Die Installation cached nur Offline-Seite und öffentliche Icons.

`visibilitychange`, `pagehide`, `pageshow`, `online` und `offline` verbinden diese Steuerung mit dem Browser. Die Simulation prüft die Zustandslogik, ersetzt aber keinen Test der Betriebssystemereignisse auf einem echten iPhone.

## Build und Auslieferung

Der Produktionsbuild erzeugt `/`, `/install` und `/manifest.webmanifest`. Geprüft werden Standalone-Modus, Start-/Scope-Pfad, Apple-Touch-Icon (180×180), Icons (192×192 und 512×512), Maskable-Icon und `viewport-fit=cover`. Das Nutzer-Zoom wird nicht deaktiviert. Der Dockerfile kopiert `public/` ausdrücklich in das Standalone-Image; dadurch werden Service Worker, Offline-Seite und Icons mit ausgeliefert.

Wie beim Kernprojekt benötigte die eingeschränkte Prüfumgebung einen externen Node-Telemetrie-Fallback für die nicht verfügbare RSS-Abfrage. Dieser Hilfscode ist nicht im Projekt enthalten und verändert keine Anwendungslogik. Die normalen Zielhost-/Docker-Startbefehle verwenden ihn nicht.

## Was bewusst nicht behauptet wird

- Keine erfolgreiche Installation auf einem physischen iPhone und keine Browser-Pixel-/Touch-Zertifizierung.
- Keine garantierte iOS-Hintergrundausführung. Ein laufender Rechner/VPS muss scannen.
- Keine Web-Push-Integration oder zugestellten iOS-Push-Nachrichten. Audio funktioniert nur im Vordergrund nach Interaktion; Telegram ist ein separat konfigurierbarer Backend-Kanal.
- Kein schon veröffentlichter Hosting-Link und kein bereits ausgestelltes Domain-Zertifikat.
- Keine neue On-Chain-/Axiom-Integration und keine Aufhebung vorhandener Sicherheitsblockaden.
- Kein neuer Live-/Renditetest. Die historischen Mainnet-Verbindungsbefunde des Kernprojekts sind in `VALIDATION_CORE_v0.1.md` und `mainnet-smoke-final.json` dokumentiert.

Der nächste praktische Abnahmeschritt auf dem Zielgerät ist: HTTPS-Installation, API-Anmeldung, Token-Suche, Analyst-Panel, Rotation, App-Wechsel, Netzverlust und Rückkehr testen. Paper-Orders müssen bei fehlenden oder veralteten Daten gesperrt bleiben.
