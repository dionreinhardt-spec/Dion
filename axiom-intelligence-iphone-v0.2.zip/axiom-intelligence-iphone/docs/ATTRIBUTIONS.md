# Provenienz und Abhängigkeiten

Die Anwendung ist ein unabhängiges Projekt und verwendet Axiom lediglich als bevorzugten manuellen Handelsworkflow. Axiom, Solana, Pump, PumpSwap, Raydium, Meteora, Jupiter und Robinhood sind keine Projektpartner.

Die funktionalen Event-/Account-Schemata stammen aus den offiziellen Pump-IDLs:
https://github.com/pump-fun/pump-public-docs/tree/main/idl

Jede Schema-Datei enthält Quell-URL, Abrufdatum und SHA-256 der Originaldatei. Die durch die offiziellen Pump-Dokumente empfohlenen Pakete `@pump-fun/pump-sdk@4.1.0` und `@pump-fun/pump-swap-sdk@2.1.0` sind als MIT gekennzeichnet und wurden ergänzend auf ihre Feldlisten geprüft. Die SDK-Tarballs sind nicht als ausführbare Abhängigkeit eingebaut.

Die realen Fixtures sind öffentlich empfangene Solana-Runtime-Logs mit Signatur, Slot und Empfangszeit. Sie werden als historische Regressionsevidenz verwendet und nicht in den Live-Feed eingespeist.

Next.js, React, FastAPI, SQLAlchemy, HTTPX, Redis-Client, Websockets, Pydantic, Lucide und weitere Pakete unterliegen ihren eigenen Lizenzen. Konkrete Versionen sind in `frontend/package-lock.json` und `backend/requirements.lock` festgehalten. Images werden erst beim eigenen Compose-Build bezogen.
