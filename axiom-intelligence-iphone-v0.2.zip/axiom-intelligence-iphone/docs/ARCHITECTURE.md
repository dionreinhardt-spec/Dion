# Architektur und Datenmodell

## Grenzen und Datenfluss

```mermaid
flowchart TD
    S["Solana confirmed logs"] --> P["Pump Queue"]
    S --> A["PumpSwap Queue"]
    P --> D["Geprüfter Event-Decoder"]
    A --> D
    D --> DB["SQL Event-Inbox"]
    D --> H["Begrenzter Hot State"]
    E["Preis, DEX und Mint RPC"] --> H
    H --> SC["Score und Datenqualität"]
    SC --> R["Risikoprüfung"]
    R --> UI["Dashboard / manuelle Prüfung"]
    UI --> B["Paper Broker"]
    B --> DB
    SC --> C["Optionaler Redis-Snapshot"]
    RH["Robinhood Raw-Log-Adapter"] --> DB
```

Der Backend-Prozess ist ein einzelner Collector/Analytics-Owner. WebSocket-IO, langsame Enrichment-Abfragen, Signalberechnung und Paper-Ausführung sind getrennte Module. Die Live-Ordergrenze enthält keinen Signer und keinen Transaktionsversand.

Pump und PumpSwap haben getrennte begrenzte Queues. Neue PumpSwap-Pools benötigen RPC-Nachschläge; diese dürfen den Pump-Decoder nicht aufhalten. Überläufe werden gezählt und setzen die Abdeckung des betroffenen Venues zurück. Normale Transportabbrüche setzen alle betroffenen Fenster zurück. Es gibt kein verlustfreies Solana-Backfill-Versprechen.

## Dateien

| Modul | Verantwortlichkeit |
| --- | --- |
| `config.py` | Validierte Umgebungsvariablen, Secret-Typen, Risikolimits |
| `adapters/solana.py` | WebSocket-Subscriptions, Quellen-/Zeitprüfung, bekannte Event-Normalisierung |
| `adapters/borsh.py` | Bounded Schema-Reader, Discriminator, Runtime-Stack und CPI-Rollback |
| `adapters/*_schema.json` | Offizielle IDL-Verträge mit Herkunft/Hash |
| `adapters/evm.py` | Eigenständiger Robinhood-Transport, Chain-Checks, Allowlist, Raw-Logs/Reorg-Tombstones |
| `providers.py` | RPS-Gates, Parallelitätslimit, Retries, Retry-After, Request-/Kosten-Zähler |
| `enrichment.py` | DEX-Metadaten, Mint-Rechte, größte Token-Konten/Eigentümer |
| `analytics.py` | Zeitfenster, Net Flow, Konzentrations-/Roundtrip-Heuristiken, erklärbarer Score |
| `wallets.py` | FIFO-Metriken beobachteter Wallet-Lots, unvollständige Historie explizit |
| `social.py` | Offizielle opt-in Quellen, Contract-Matching, Themenbaseline, optionale Alerts |
| `paper.py` | Ledger, Kostenmodell, Risikolimits, idempotente Fills, Exits |
| `execution.py` | Separater Vertrag für künftige autorisierte Ausführung; Live-Implementierung gesperrt |
| `engine.py` | Aufgaben-Lebenszyklus, 1s-Zielschleife, priorisierte Enrichment-Auswahl, Wiederherstellung |
| `api.py` | Authentifizierte Read-/Paper-API, Dashboard-WS, Health, Metriken |
| `backtest.py` / `performance.py` | Arrival-Time-Replay, feste chronologische OOS-Fenster, Kostenkennzahlen |

## Datenbank

SQLAlchemy erzeugt Schema v1 beim ersten Start für SQLite und PostgreSQL. Die aktuelle Version enthält kein automatisches Upgrade bestehender fremder Schemas. Vor späteren inkompatiblen Upgrades ist eine explizite Migration erforderlich.

| Tabelle / Schlüssel | Inhalt | Invariante |
| --- | --- | --- |
| `events.id` (PK) | Ketten-/Transaktions-/Event-Identität | Unique; doppelte Zustellung verändert den Flow nicht |
| `events.kind` | `trade`, `market`, `security`, `feed`, `lifecycle`, `signal`, `social`, `evm-raw` | Quellen und Datenarten bleiben getrennt |
| `events.token` | Contract/Mint, bei globalem Feed leer | Keine Symbol-Joins |
| `events.timestamp` | Quellen-/Beobachtungszeit, je Datenart | Index für Replay/Retention |
| `events.payload` | Vollständiger normalisierter Datensatz mit Provenienz | JSON; Empfangs-/Verfügbarkeitszeit bleibt erhalten |
| `state.schema` | `version: 1` | Schema-Version sichtbar |
| `state.profiles` | Watchlist, Metadaten, Sicherheitsbefunde, bekannte Vault-Eigentümer | Warmstart, keine künstliche Aktualisierung alter Zeitstempel |
| `state.paper` | Cash, Positionen, Cost Basis, Journal, Idempotenz-Resultate, Kill Switch, Breaker | Ledger-Änderung vor Bestätigung persistiert |
| `state.x-budget` | Tagesressourcen / Cursor | Keine unbegrenzten API-Reads |
| `state.telegram-cursor` | Bestätigter Update-Offset | Wiederholte Posts werden dedupliziert |
| `state.robinhood-cursor` | Letzter beobachteter Block | Überlappendes begrenztes Replay |

PostgreSQL wird im Compose-Stack tatsächlich verwendet; SQLite ist der lokale Einzelprozesspfad. TimescaleDB-Hypertables und Alembic-Migrationen sind noch nicht implementiert. Der Cache-Key `axiom:latest` hat 5 Sekunden TTL. Redis ist kein primäres Ledger und kein verlustfreier Event-Broker.

## Datenqualität und Latenz

- `timestamp`: On-Chain-Eventzeit mit Sekundengenauigkeit; nicht die Empfangszeit.
- `received_at`: lokaler Empfang, bleibt beim Restart unverändert.
- `chain_latency_s`: Empfang minus Eventzeit, kein exakter Subsekunden-Benchmark.
- `quote_price_at`: Empfangszeit des damals verfügbaren USD-Referenzpreises. Jupiter liefert hier keinen zuverlässigen Wallclock-Quote-Zeitstempel.
- DEX Screener liefert in diesem Vertrag keinen garantierten Upstream-Preiszeitstempel; dieser bleibt im Dashboard unbekannt.
- `evaluation_ms` misst CPU/IO-Dauer der internen Neubewertung, nicht die vollständige Signal- oder Ausführungslatenz.
- Fenster, die seit Start/letzter Lücke noch nicht vollständig beobachtet wurden, dürfen keine vollständige Historie behaupten. Hot-Retention kann lange Fenster verkürzen.
- Fehlende USD-Bewertung, Holder-Werte und Smart-Money-Daten bleiben `null`. Sie werden weder durch Nullbestände noch durch Beispieldaten ersetzt.

Ein Signifikanz-/Wahrscheinlichkeitsmodell, SLAs und Lastbenchmarks sind noch nicht vorhanden. Die 1s-Neubewertung ist ein Ziel, keine garantierte HFT-Latenz.
