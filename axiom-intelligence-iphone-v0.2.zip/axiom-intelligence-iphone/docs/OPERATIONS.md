# Konfiguration, API und Betrieb

## Provider

`.env.example` ist vollständig kommentiert. `scripts/configure.py` erzeugt neue lokale Zufallswerte und überschreibt keine vorhandene `.env`. Zugangsdaten werden nicht ausgegeben. `.env` gehört nicht in Git oder ein geteiltes Archiv.

1. Eigenen Solana-RPC-Vertrag wählen. HTTP und WS müssen auf dasselbe Mainnet zeigen und `logsSubscribe`, `getAccountInfo(jsonParsed)`, `getTokenLargestAccounts` und `getMultipleAccounts` unterstützen.
2. RPS/Concurrency nach dem **eigenen** Tarif setzen. Ein HTTP-Key mit Query- oder Pfadtoken bleibt ausschließlich im Backend. Authentifizierte URLs erscheinen nicht in Fehlertexten.
3. Öffentliche RPCs dienen dem Starttest; teure Holder-Methoden können limitiert oder gesperrt sein. Fehlt die Prüfung, blockiert das System Einstiege.
4. Für den schmalen ersten Betrieb `INTEL_WATCH_PUMPSWAP=false` und eine kleinere Kandidatenzahl erwägen. Das entfernt keine Sicherheitskontrolle; es reduziert den überwachten Datenumfang. PumpSwap benötigt Pool-RPC-Lookups und mehr Kapazität.
5. Jupiter-Preise verwenden den recherchierten keyless Price-v3-Vertrag mit konservativem RPS-Limit. Der Adapter unterstützt derzeit keinen Jupiter-Key; bei dauerhaftem 401/429 bleibt der Flow unbewertet. Einen Key-Header nur anhand der aktuellen offiziellen Doku ergänzen.
6. DEX-Abfragen sind gebündelt und rotieren über Kandidaten. Die Watchlist und Positionen werden priorisiert. Bei 150 Kandidaten kann ein Token später als das Datenalterlimit angereichert werden; in diesem Fall wird er blockiert.

Einsekündige interne Auswertung ist kein sekundliches Polling jeder externen API. Der Browser nutzt WebSocket-Snapshots; bei Ausfall pollt er nur das eigene Backend.

## Social

X: `INTEL_X_BEARER_TOKEN` und eine gezielte `INTEL_X_QUERY` setzen. Standard maximal 100 Post-Ressourcen/Tag; die tatsächliche Rechnung und Änderungen im Developer-Account prüfen. Die Ressourcenbegrenzung ist kein absoluter Rechnungsschutz bei Provider-Retries, Abstürzen zwischen Antwort und Budgetpersistenz oder geänderten Tarifen. Providerseitiges Ausgabenlimit zusätzlich verwenden.

Telegram: eigenen Bot rechtmäßig zu gewünschten Channels hinzufügen; numerische IDs in `INTEL_TELEGRAM_READ_CHANNELS`. Ein vorhandener Webhook verhindert `getUpdates`; der Code löscht ihn nicht automatisch. Für Benachrichtigungen zusätzlich eigenes Ziel unter `INTEL_TELEGRAM_ALERT_CHAT_ID` und `INTEL_TELEGRAM_ALERTS_ENABLED=true` setzen. Ohne diese Werte wird nichts versendet. Keine Nachrichten wurden beim Erstellen/Prüfen dieses Projekts versendet.

Reddit/Discord sind noch nicht eingebunden. Es gibt keine Cookie-/Session-Extraktion.

## Robinhood

Standardmäßig ausgeschaltet. Für den Raw-Log-Modus: offiziellen Mainnet-RPC und Provider-JSON-RPC-WS eintragen, Chain-ID 4663, explizit verifizierte Contract-Adressen in `INTEL_ROBINHOOD_CONTRACTS`. Keine fremden Factory-Adressen von anderen EVM-Chains übernehmen. Ohne Allowlist startet der Adapter absichtlich nicht. Testnet separat mit Chain-ID 46630 konfigurieren. Rohlogs sind keine Signale und werden nicht mit Solana-Contracts vermischt.

Der Adapter reagiert auf `removed`-Logs mit Tombstones und replayt überlappend. Er ist kein vollständiger finalisierter EVM-Indexer und besitzt keine ABI-/Tax-/Honeypot-Analyse. Nach einer Lücke von mehr als 20.000 Blöcken wird manuelles historisches Backfill benötigt; es gibt keinen stillen Sprung zum aktuellen Head.

## API

Wenn `INTEL_API_TOKEN` gesetzt ist: HTTP `Authorization: Bearer ...`. Dashboard-WS: Token ausschließlich als erstes JSON-Frame `{ "token": "..." }`. Origin-Allowlist schützt Browserzugriffe zusätzlich. Health-Live ist bewusst ohne Token.

| Methode | Route | Wirkung |
| --- | --- | --- |
| GET | `/health/live` | Prozess lebt; keine Aussage über Marktdaten |
| GET | `/health/ready` | DB und Auswertung aktiv; im Live-Modus Stream verbunden |
| GET | `/api/snapshot` | Scanner, Quellen, Portfolio, Wallets, Social und Capabilities |
| GET | `/api/token/{mint}` | Beobachtete Token-Analyse |
| WS | `/ws` | Snapshot jede Sekunde als Ziel |
| POST | `/api/watch` | `{ "token": "FULL_SOLANA_MINT" }` |
| POST | `/api/paper/buy` | `{ "token": "...", "notional_usd": 50, "idempotency_key": "unique-order-key" }` |
| POST | `/api/paper/{mint}/close` | `{ "fraction": 0.5, "idempotency_key": "unique-close-key" }` |
| POST | `/api/risk/kill?active=true` | Persistierter Paper-Kill-Switch |
| GET | `/metrics` | Authentifizierte Prometheus-Textmetriken |

Keine Live-Order-Route. Clients dürfen keine Preise/Scores zur Autorisierung eines Kaufs übermitteln; der Server bewertet neu. Ein freigegebener Entry-Kandidat ist weiterhin nur ein Paper-Kandidat.

## Zustände, Überwachung, Backups

- Genau **ein** Backend-Worker. SQLite-Dateisperre / PostgreSQL-Advisory-Lock verhindert konkurrierende Collector-Instanzen.
- `health/ready` ist keine Zertifizierung vollständiger Historie, beendeter Warmup oder vertrauenswürdiger Token-Prüfung. Diese Bedingungen sind pro Token sichtbar.
- Fehlertexte sind redigiert und Logging wird pro Komponente gedrosselt. Keine Private Keys, keine Signer und keine unbegrenzten Wallet-Approvals.
- HTTP-Zugriffslogging ist im Startbefehl ausgeschaltet; keine Tokens als Query-Parameter verwenden.
- Redis ist optional. Ein Fehler führt zu sichtbar markiertem In-Process-Fallback, nicht zu einem neuen Paper-Konto.
- Hot-Events sind begrenzt, Queue-Überläufe sichtbar. SQL-Events werden nach 30 Tagen bereinigt. Lange Fenster/Wallet-Teilhistorien sind somit nicht dauerhaft vollständig.
- PostgreSQL regelmäßig mit `pg_dump` in ein eigenes Backupziel sichern; Restore testen. Für SQLite vor konsistentem Dateibackup Collector sauber stoppen oder SQLite-Backup-API verwenden.
- Docker-Restart-Policies helfen bei Prozessabbrüchen. Eine externe Überwachung muss `ready`, `dropped_events`, `decode_errors`, Datenalter und Provider-Budgets prüfen. Ein ausgeliefertes Grafana-/Alertmanager-Deployment ist nicht enthalten.
- Metriken und Untersuchungsdaten enthalten öffentliche Wallet-Adressen; der persönliche Paper-Ledger und API-Token sind privat zu behandeln.

## IDL-Aktualisierung

```bash
python scripts/update_idl.py --commit VOLLSTAENDIGER_GEPRUEFTER_40_STELLIGER_SHA
cd backend
python -m pytest -q
```

Diff und reale bestätigte Regressionstransaktionen prüfen. Ein neuer Schemahash allein beweist keine Deployment-Übereinstimmung. Nicht durch Abschalten der Schema-Blockade „reparieren“. Die aktuellen empfohlenen offiziellen NPM-SDKs wurden zusätzlich auf ihre IDL-Feldlisten geprüft; auch sie erklärten den beobachteten zusätzlichen Anhang beim Erstellungsstand nicht.
