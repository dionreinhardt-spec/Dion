# Technische Realitätsprüfung

Geprüft am 2. November 2026. Ausschließlich Primärquellen für technische Schnittstellen. Eine Dokumentationsprüfung ersetzt keine Ausführung gegen einen konkreten Provider-Vertrag. Dies ist eine gezielte Integrationsprüfung für den ersten Abschnitt, keine vollständige Bestandsaufnahme aller kommerziellen Anbieter.

## Axiom

Offizielle Quellen:

- https://docs.axiom.trade/llms.txt
- https://docs.axiom.trade/axiom/swap/market.md
- https://docs.axiom.trade/faqs
- https://docs.axiom.trade/perpetuals/trading-on-hyperliquid
- https://axiom.trade/exp

Der öffentliche Dokumentationsindex enthält keine öffentliche Trading-API-Referenz und kein belastbares Token-Deeplink-Schema. Der dokumentierte Market-Workflow verwendet https://axiom.trade/pulse und Contract-Suche. „API nicht nachgewiesen“ ist nicht die Behauptung, dass intern keine API existiert. Drittanbieter-SDKs, Session-Endpunkte und ähnlich benannte fremde Domains sind kein Nachweis einer offiziell autorisierten API.

Die FAQ nennt Solana; die öffentlich sichtbare Axiom-Weboberfläche weist zusätzliche Chain-Auswahlmöglichkeiten aus. Wegen dieser unterschiedlichen Dokumentationsstände wird keine vollständige aktuelle Axiom-Chain-Abdeckung zugesichert. Der MVP integriert ausschließlich den dokumentierten manuellen Solana-Suchworkflow. Hyperliquid-Perps sind eine andere Produktkategorie und keine Memecoin-Spot-API.

Die ältere Pulse-Seite nennt Raydium-Migrationen. Für Pump wird die aktuelle Pump-Primärquelle herangezogen, die PumpSwap nennt. Weder Cupsey noch Kimchi wird eine persönliche proprietäre Strategie zugeschrieben.

## Solana und Pump

- https://solana.com/docs/rpc
- https://solana.com/docs/rpc/websocket/logssubscribe
- https://solana.com/docs/rpc/http/gettransaction
- https://github.com/pump-fun/pump-public-docs
- https://github.com/pump-fun/pump-public-docs/blob/main/docs/PUMP_PROGRAM_README.md
- https://github.com/pump-fun/pump-public-docs/blob/main/docs/PUMP_SWAP_README.md
- https://github.com/pump-fun/pump-public-docs/blob/main/idl/pump.json
- https://github.com/pump-fun/pump-public-docs/blob/main/idl/pump_amm.json
- https://github.com/pump-fun/pump-public-docs/blob/main/docs/instructions/TRADE_V3.md

Implementierte Program-IDs:

| Programm | Mainnet-Adresse |
| --- | --- |
| Pump | `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P` |
| PumpSwap | `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA` |

`logsSubscribe.mentions` unterstützt eine Adresse pro Subscription. Der Adapter abonniert deshalb getrennt. `confirmed` ist eine Bestätigung, keine endgültige Finalität; tote Forks bleiben ein Restrisiko. Ein endgültiger Solana-Reorg-Reconciler ist noch nicht implementiert.

Aktuelle Pump-Dokumente führen tokenbasierte Quotes, Multi-Hop und virtuelle Quote-Reserven auf. Der MVP verarbeitet nur SOL/USDC. Virtuelle PumpSwap-Reserven sind vorzeichenbehaftet (`i128`); sie werden nicht als reale ausführbare Liquidität ausgegeben. Alte SOL-only-Instruktionen emittieren im aufgezeichneten Mainnet-Trade einen Null-Pubkey als Quote; nur für die expliziten alten SOL-Instruktionsnamen wird er SOL zugeordnet. Neue unbekannte Quote-Konventionen werden verworfen.

**Empirischer Befund:** Die Fixtures enthalten zusätzliche, im veröffentlichten Schema nicht deklarierte Bytes. Der Code akzeptiert bekannte Felder als Beobachtung, kennzeichnet den Anhang und blockiert darauf gestützte Trades. Unvollständige bekannte Felder, ungültige Discriminator, übergroße Felder und fehlgeschlagene Aufrufpfade bleiben Fehler. Die Schema-Dateien enthalten Quell-URL, Hash und Abrufdatum; `scripts/update_idl.py` verlangt einen geprüften vollständigen Commit-SHA.

## Marktdaten und Hochgeschwindigkeits-Provider

| Quelle | Geprüfte offizielle Schnittstelle | Kosten / technische Grenze | Im MVP |
| --- | --- | --- | --- |
| Solana Public RPC | HTTPS/WS laut Solana-Doku | Geteilt und begrenzt, kein Produktions-SLA; Last-/Methodenlimits variieren | Ja, Startvorgabe für Verbindungstest |
| Eigener RPC-Vertrag | Derselbe standardisierte Solana-JSON-RPC-Vertrag | Häufig kostenpflichtig, RPS/Concurrency/Archivzugriff vertraglich prüfen | Austauschbar über HTTP-/WS-Konfiguration |
| Jupiter | https://developers.jup.ag/docs/llms.txt · `GET https://api.jup.ag/price/v3` | Laut aktuellem Index keyless 0,5 RPS; API-Key für mehr Durchsatz/Analytics | USD-Referenzpreis, gedrosselt auf <0,5 RPS |
| Jupiter Swap v2 | `https://api.jup.ag/swap/v2/order`, `/build`, `/execute` laut Index | Autorisierung, Quote-Gültigkeit, Routing und aktuelle Gebühren prüfen | Recherchiert, keine Orderausführung implementiert |
| DEX Screener | https://docs.dexscreener.com/api/reference · `/tokens/v1/solana/{mints}` | Bis 30 Mints; dokumentiert 300 Requests/min für Token/Paar-Abfragen; Upstream-Preiszeit nicht garantiert | Ja, eigenes Limit deutlich darunter |
| Yellowstone / Triton | https://docs.triton.one/project-yellowstone/dragons-mouth-grpc-subscriptions | Backend-gRPC, Provider-Zugang/Tarif, passende Protobuf-/Client-Version erforderlich | Noch nicht implementiert |
| Raydium | https://docs.raydium.io/llms.txt | Offizielle SDK-/IDL-/REST-Verträge verfügbar; Native Decoder je Programm nötig | Nur DEX-Screener-Metadaten |
| Meteora | https://docs.meteora.ag/llms.txt | DLMM/DAMM/DBC unterscheiden sich; Pool-TVL ist keine Route-Tiefe | Nur DEX-Screener-Metadaten |

Triton beschreibt `SubscribeDeshred` als gesonderte kostenpflichtige Beta ohne Ausführungsmetadaten und ohne Bestätigungsgarantie. Solche Daten wären allein keine Grundlage für einen als bestätigt ausgegebenen Trade. Provider-Tarife werden nicht als feste Monatsbeträge erfunden. Das Dashboard zeigt konfigurierbare feste Kosten, gezählte RPC-Anfragen und eine eigene variable Kostenschätzung.

## Robinhood Chain

- https://docs.robinhood.com/chain/
- https://docs.robinhood.com/chain/connecting/
- https://docs.robinhood.com/chain/deploy-smart-contracts/

| Netzwerk | Chain-ID | Öffentlicher HTTP-RPC |
| --- | --- | --- |
| Mainnet | 4663 | `https://rpc.mainnet.chain.robinhood.com` |
| Testnet | 46630 | `https://rpc.testnet.chain.robinhood.com` |

Die aktuelle offizielle Doku nennt EVM-Kompatibilität, ETH als Gas-Token und einen Alchemy-HTTP-/WebSocket-Vertrag (`robinhood-mainnet.g.alchemy.com/v2/{API_KEY}`). Öffentliche Endpunkte sind begrenzt und für Produktion nicht empfohlen. Der öffentliche **Sequencer Feed ist kein JSON-RPC-`eth_subscribe`-WebSocket**.

Der optionale Adapter prüft HTTP- und WebSocket-Chain-ID und protokolliert nur Raw-Logs explizit eingetragener Contracts. Keine konkrete Memecoin-DEX-Factory wurde für diesen MVP als aktuelles Deployment verifiziert; die Allowlist ist deshalb leer. Es gibt keine erfundenen Pair-Factory-Adressen, keine vermeintlichen Mainnet-Spot-Signale und keine Stocks-API als Ersatz für DEX-Flow.

## Social

| Quelle | Primärquelle | Zugang/Kosten | Implementierung |
| --- | --- | --- | --- |
| X | https://docs.x.com/x-api/getting-started/pricing | Aktuelle Doku: Pay-per-use, Posts-Read $0,005/Ressource; Berechtigungen und Preis vor Betrieb im eigenen Account prüfen | Opt-in Recent Search; tägliches Ressourcenbudget |
| Telegram | https://core.telegram.org/bots/api · https://core.telegram.org/bots/faq | Eigener Bot mit legitimen Channel-Rechten; `getUpdates` und Webhooks schließen sich aus | Opt-in Channel-Post-Empfang und optionale Alerts |
| Discord | https://docs.discord.com/developers/events/gateway | Autorisierter Bot, Server-Rechte, ggf. privilegierter Message-Content-Intent | Noch nicht implementiert |
| Reddit | https://redditinc.com/policies/data-api-terms | Genehmigter API-Zugang, OAuth und aktuelle Nutzungsbedingungen | Noch nicht implementiert |

Kein Scraping, keine Nutzer-Cookie-Extraktion, keine Zugangsumgehung. Telegram-Absender ist auf Bot-API-Ebene oft ein Channel, keine natürliche Person. Vier verschiedene Accounts sind kein Beweis vier unabhängiger Menschen. Lexikalische Themenzählung wird nicht als trainierte KI ausgegeben.
