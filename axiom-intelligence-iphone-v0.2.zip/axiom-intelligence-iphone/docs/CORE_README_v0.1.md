# Kernanleitung · Backend v0.1 (Pfade für die iPhone-Ausgabe)

Lokal/VPS betreibbarer, unabhängiger **Solana Trading-Intelligence-MVP** mit Next.js-Terminal, FastAPI, bestätigten On-Chain-Events, transparentem Scoring und Paper Trading. Keine Zugehörigkeit zu Axiom Trade. Keine Live-Orderausführung und keine Private Keys.

**Stand der Realitätsprüfung: 2. November 2026.** Dies ist der erste ausführbare Projektabschnitt, nicht die Fertigstellung sämtlicher acht Phasen.

## Wichtiger aktueller Befund

Die im Mainnet empfangenen Pump/PumpSwap-Events enthalten zusätzliche Bytes gegenüber den veröffentlichten IDLs. v0.1 dekodiert die bekannten Felder zur Beobachtung und blockiert Einstiege bei unbekannten Event-Anhängen. Die realen Regression-Fixtures liegen in `backend/fixtures/`. Das System umgeht diese Blockade nicht über einen Konfigurationsschalter. Sie muss durch eine geprüfte, zum Deployment passende Schemaaktualisierung behoben werden.

Keine positiven Renditen sind nachgewiesen. Ein hoher Score ist eine nachvollziehbare Heuristik, keine trainierte oder kalibrierte Gewinnprognose.

## Schnellstart mit Docker

Voraussetzungen: Linux/VPS oder Docker Desktop, Docker Engine mit Compose v2, mindestens 2 CPU-Kerne / 4 GB RAM als Startpunkt. Datenmengen und Provider bestimmen die tatsächliche Kapazität.

```bash
unzip axiom-intelligence-iphone-v0.2.zip
cd axiom-intelligence-iphone
python3 scripts/configure.py
# .env öffnen: produktiven RPC-Provider und optional Social-Zugänge konfigurieren
# Den erzeugten INTEL_API_TOKEN nur im eigenen Dashboard eingeben.
docker compose up --build -d
docker compose logs -f backend
```

Dashboard: **http://localhost:8080**. Unter „Verbindung & API“ den Wert von `INTEL_API_TOKEN` aus `.env` eingeben und „Verbindung aktualisieren“ wählen. Es wird kein Token als URL-Parameter übertragen oder im Browser dauerhaft gespeichert.

Auf einem VPS bleibt Port 8080 standardmäßig an Loopback gebunden:

```bash
ssh -L 8080:127.0.0.1:8080 user@dein-vps
```

Danach lokal `http://localhost:8080` öffnen. Für einen öffentlich erreichbaren Betrieb: eigenen TLS-Reverse-Proxy mit Zugriffsschutz konfigurieren und dessen Origin in `INTEL_ALLOWED_ORIGINS` eintragen. Keine Datenbank-/Redis-Ports sind veröffentlicht.

Beenden: `docker compose down`. Daten bleiben in den benannten Volumes. **`down -v` würde sie löschen.**

## Ohne Docker

Python 3.12+ und Node.js 24+, npm. SQLite ist für einen einzelnen lokalen Collector enthalten.

```bash
cd axiom-intelligence-iphone
python3 scripts/configure.py
python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.lock
# Terminal 1
cd backend
uvicorn axiom_intel.api:app --host 127.0.0.1 --port 8000 --workers 1 --no-access-log
```

In einem zweiten Terminal:

```bash
cd axiom-intelligence-iphone/frontend
npm ci
npm run dev
```

Dashboard: http://localhost:3000. `.env` im Projektstamm wird vom Backend gelesen. Für den Produktionsmodus im Frontend: `npm run build && npm start`. Die Node-Konfiguration für den Zielhost muss `process.memoryUsage()` unterstützen.

Zum reinen Offline-Start `INTEL_MODE=offline` setzen. Die Oberfläche zeigt dann gespeicherte Beobachtungen oder einen leeren Zustand; sie erzeugt keine Demo-Livewerte.

## Implementiert

| Bereich | Tatsächlicher Umfang |
| --- | --- |
| Solana-Stream | `logsSubscribe`, commitment `confirmed`, Pump / optional PumpSwap, Reconnect mit Backoff |
| Event-Verifikation | Runtime-Aufrufstack, Ausschluss fehlgeschlagener CPIs, IDL-Discriminator, begrenzter Borsh-Reader, Schemaabweichungen als Trade-Blocker |
| Preis/Flow | SOL- und USDC-Quotes; echte Jupiter-USD-Referenzwerte; getrennte Quelle/Empfangszeit; fehlende USD-Werte bleiben unbekannt |
| Fenster | 5s, 15s, 30s, 1m, 5m, 15m, 1h, 24h; Abdeckung und Datenlücken werden berücksichtigt |
| Enrichment | DEX Screener, bis 30 Mints je Anfrage, gestaffelte Abfragen; Market Cap/FDV/Liquidität/5m-Volumen getrennt von On-Chain-Flow |
| Sicherheit | Mint/Freeze Authority, Token-2022-Default-Deny für ungeprüfte Erweiterungen, Top-20-Kontostichprobe mit aufgelösten Eigentümern und bekannten Vault-Ausschlüssen |
| Scoring | 12 konfigurierbare Faktoren; fehlende Faktoren = null und 0 Punkte, keine optimistische Neugewichtung |
| Strategie | `momentum-v1`: explizite Bedingungen und Invalidierung; andere Entry-Modelle sind spezifiziert, noch nicht aktiviert |
| Wallets | FIFO-Metriken für beobachtete Teilhistorie; kein als „Smart Money“ ausgegebenes unvollständiges Ranking |
| Social | Opt-in X Recent Search und autorisierte Telegram-Channel-Posts; Voll-Contract-Zuordnung; lexikalische Narrative-Baseline |
| Paper Trading | Manuelle Einstiegsbestätigung, Cash/Positionsledger, modellierte Kosten/Impact, partielle Exits, Trailing/Stop/Zeit-/Momentum-/Security-Exits |
| Risiko | Größen-/Exposure-/Tagesverlust-/Drawdown-/Positionslimits, Kill Switch, frische Daten, Idempotenz, atomare Ledger-Speicherung |
| Persistenz | SQLite oder PostgreSQL, Event-Deduplikation, Wiederherstellung, Collector-Singleton-Lock; Redis als optionaler Snapshot-Cache |
| EVM | Separater Robinhood-Raw-Log-Adapter mit Chain-ID-Prüfung, Contract-Allowlist, begrenztem Replay und Removed-Log-Tombstones; standardmäßig aus |
| Betrieb | Health-Endpunkte, Prometheus-Textmetriken, redigierte Fehler, begrenzte Hot-Daten/Queues, 30-Tage-Event-Retention |
| Validierung | Tests, reale öffentliche On-Chain-Fixtures, kostenbewusster Arrival-Time-Replay und chronologische Auswertungsfenster |

## Noch nicht verfügbar

- Native Raydium-/Meteora-/Jupiter-Router-Swap-Decoder; DEX-Metadaten sind keine native Event-Integration.
- Yellowstone-gRPC-Transport. Die offizielle Schnittstelle ist recherchiert; der MVP verwendet JSON-RPC-WebSockets.
- Vollständiger Holder-Indexer, Funding-Graph, sicherer Insider-/Dev-/Sniper-Nachweis, verifiziertes historisches Smart-Money-Ranking.
- Reddit-/Discord-Collector, trainiertes Narrativ-Modell, semantische Meme-Bildanalyse, sichere Shill-/Bot-Klassifikation.
- Vollständige Robinhood-DEX-/Token-Deployment-/Honeypot-/Tax-/Proxy-Analysen oder Base/Ethereum-Implementierungen.
- Axiom-Portfoliozugriff, verifizierter Token-Deeplink oder dokumentierte öffentliche Trading-API. Es gibt nur den offiziellen Pulse-Link mit Contract-Suche.
- Reale Orders oder ein versteckter Live-Schalter. `ExecutionAdapter` ist eine Schnittstellengrenze für eine spätere separat autorisierte Implementierung.
- Historischer Marktdatenbestand, produktionsreifer Optimierer, realistischer MEV-/Failure-Simulator, Renditenachweis, HA-Cluster oder 24/7-Soak-Zertifizierung.

## Tests

```bash
. .venv/bin/activate
cd backend
python -m pytest -q
cd ../frontend
npm run typecheck
npm run build
```

Die Tests verwenden klar benannte Testdaten und öffentliche aufgezeichnete Mainnet-Logs. Sie füllen den Live-Scanner nicht mit Beispielen.

## Replay / Out-of-Sample

Der laufende Collector speichert Trades, empfangene Markt-/Sicherheits-Snapshots und Feed-Zustände. Diese Ankunftszeiten sind entscheidend: ein alter Chain-Zeitstempel macht verspätet empfangene Daten nicht rückwirkend verfügbar.

```bash
# Aus backend/ mit aktivierter Python-Umgebung; verwendet dieselbe .env
PYTHONPATH=. python ../scripts/export_replay.py --out ../replays/recorded.jsonl
python -m axiom_intel.backtest ../replays/recorded.jsonl --out ../reports/replay.json --latency-s 1
# --oos-start UNIX_TIMESTAMP trennt Warmup und Test; nur vorab gewählte Gewichte verwenden
# --walk-forward-days 7 liefert feste chronologische Testfenster, keine automatische Optimierung
```

Einstiege benötigen einen später empfangenen Trade. Kosten und Impact sind Modelle; es werden keine historischen DEX-Fills behauptet. Ohne Feed-/Security-Nachweis entstehen keine freigegebenen Einstiege. Teil-Exit-Kennzahlen sind als solche benannt. Sharpe wird unter 30 Tagesbeobachtungen nicht ausgegeben.

## Dokumentation

- [Offizielle Schnittstellen, Kosten und Realitätsprüfung](docs/RESEARCH.md)
- [Architektur und Datenvertrag](docs/ARCHITECTURE.md)
- [API-/Provider-Konfiguration und Betrieb](docs/OPERATIONS.md)
- [Strategien, Score und Risikomodell](docs/STRATEGIES.md)
- [Prüfergebnisse und Grenzen](docs/VALIDATION.md)
- [Offizieller API-Index des Backends](http://localhost:8000/docs) bei lokalem Backend-Betrieb; in Compose ist Port 8000 intern.
