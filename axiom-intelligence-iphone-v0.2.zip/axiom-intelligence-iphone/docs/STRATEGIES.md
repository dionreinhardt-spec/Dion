# Strategien, Scoring und Risiko

## Aktiv: momentum-v1

Alle folgenden Bedingungen müssen gleichzeitig vorliegen:

1. Mindestens 60 Sekunden seit Kandidatenbeginn und letzter relevanter Datenlücke.
2. Frischer bestätigter Trade, rechtzeitig eingetroffen, vollständige USD-Bewertung im 30s-Fenster.
3. Frische Markt-/Sicherheitsdaten, mindestens $25.000 gemeldete Liquidität.
4. Keine aktiven Mint-/Freeze-Rechte, ungeprüften kritischen Token-2022-Erweiterungen oder unbekannten Event-Anhänge.
5. Mindestens 8 Käufer-Adressen in 30s. Adressen sind nicht automatisch unabhängige natürliche Personen.
6. Positiver Nettofluss über 5s, 15s und 30s.
7. USD-Volumen in den letzten 30s mindestens 1,5× dem vorhergehenden 30s-Fenster.
8. Positiver Preisfortschritt im Vergleich zur vorherigen Periode, höchstens 40%; Quellpreise weichen höchstens 15% ab.
9. Keine dominierende einzelne Volumen-Wallet (>40%) und kein Roundtrip-Anteil >65%.
10. Größter beobachteter nicht ausgeschlossener Eigentümer höchstens 20% der Supply-Stichprobe; Score mindestens 62.
11. Portfolio-Limits erlauben den Einstieg. Für den Paper-Fill ist eine manuelle Bestätigung erforderlich.

Das ist eine vorsichtige Startheuristik. Die Schwellen sind konfigurierbar und **nicht auf positive Rendite kalibriert**. Token-2022-Metadata-Extensions werden zugelassen; das bedeutet keine Sicherheitsgarantie.

## Geplante Modelle — noch nicht als Signal aktiv

| Modell | Vorgesehener Entry | Invalidierung | Exit |
| --- | --- | --- | --- |
| Fresh Launch | Verifizierter Create, mehrere Käufer, ausführbare Mindesttiefe, kontrollierte Distribution | Kritische Rechte, konzentrierte Sniper, fehlende Folgekäufe | Zeitlimit, Flow-Umkehr, Liquiditätsverlust |
| Smart Money | Mehrere historisch belegte unabhängige Wallets + bestätigter Flow | Funding-Cluster, Transfers als PnL, fehlende Historie | Wallet-Verkäufe plus Flow-/Strukturbruch |
| Narrative | Früh wachsende unabhängige Erwähnungen mit eindeutigen Contracts + echter Kaufaktivität | Nur Shill-/Ticker-Matching oder kein On-Chain-Follow-through | Nachlassende Nachfrage und Flow-Bruch |
| Breakout | Vorher festgelegtes Hoch, Volumenbestätigung, ausführbarer Quote | Rückfall unter Niveau / divergierender Flow | Trailing, Zielzonen, gescheiterter Retest |
| Migration | Verifiziertes Migrationsevent und bestätigtes handelbares Zielpool | Übergangsverkaufsrisiken, fehlende Tiefe oder Rechteänderung | Liquidity Removal, nachlassende Käufer, Stop |
| Re-Entry | Vorheriger Impuls, stabilisierter Pullback, neue unabhängige Käufer | Neues Tief oder Liquiditätsabfluss | Momentum-Invalidierung, Trailing, Zeitlimit |

Für diese Modelle fehlen jeweils Daten/Decoder/Kalibrierung. Ihre Beschreibung ist keine versteckte Implementierung und keine Empfehlung für einen aktuellen Token.

## Transparentes Score-Modell

Gewichte in `config/weights.json`, Summe 100. Fehlende Features tragen 0 Punkte bei; die übrigen Gewichte werden nicht erhöht. Aktuell fehlen insbesondere voll belegtes Smart Money, Holder-Wachstum, kalibrierte Marktbedingungen und trainierte Narrative-Stärke. Deshalb ist die erreichbare Punktzahl ohne diese Daten begrenzt.

Capital Inflow ist der gleich gewichtete Mittelwert von:

- Nettofluss relativ zur Liquidität (5% als Sättigungswert),
- Anzahl verschiedener Käufer-Adressen (25 als Sättigungswert),
- Anteil Bruttokäufe am Bruttovolumen,
- Persistenz positiven Flows in 5/15/30s,
- Abschlag für eine dominierende Volumen-Wallet,
- Abschlag für Wallets mit Käufen und Verkäufen im selben Fenster.

Die Roundtrip-Heuristik beweist weder Wash Trading noch Self-Trading. Wallet-Clustering benötigt einen Funding-/Transfergraph, der noch fehlt. `risk_score` und `confidence` sind ebenfalls Heuristiken; `scam_probability` bleibt unbekannt.

## Paper-Ausführung

Standardkonto $10.000 virtuell. Pro Trade höchstens 0,5% modelliertes Risiko, maximal 5% Positionsgröße und 20% Portfolio-Exposure, höchstens vier Positionen. Tagesverlustlimit 3%, Drawdownlimit 10%. Handelstag standardmäßig Europe/Berlin; konfigurierbar.

Die Größe wird aus Risikobudget, Stop-Abstand, konservativem Rundlauf-Kostenbudget, freien Mitteln, Exposure und Impact-Limit begrenzt. Das schützt nicht vor einer Kurslücke oder einem nicht ausführbaren Stop.

Das Paper-Modell verwendet den letzten frischen beobachteten Tradepreis, 100 bps Basis-Slippage, 100 bps Gebühren pro Seite und $0,10 modellierte Priority Fee pro Seite. Zusätzlich:

`impact = notional / (reported_liquidity / 2 + notional)`

`buy_fill = signal_price × (1 + base_slippage + impact)`

`sell_fill = current_price × (1 - base_slippage - impact)`

Das ist ein explizites konservatives Modell, **keine reale Pool-Simulation und keine zugesicherte Route-Ausführung**. DEX-TVL kann erheblich von ausführbarer Tiefe abweichen. Maximaler modellierter Impact 2%, gesamte Slippage 300 bps. Ein unveränderter Marktpreis führt wegen Rundlaufkosten zu einem Verlust.

## Exits

- Stop/Trailing: 12% unter modelliertem Entry bzw. späterem High-Water-Mark.
- TP1: bei +20% Kursfortschritt 50% schließen.
- TP2: bei +40% weitere 50% der Restposition schließen.
- Zeitlimit: 1.800 Sekunden.
- Momentum: Nettoabfluss >$1.000 in 15s und mindestens fünf verkaufende Adressen.
- Security-Emergency: neue kritische Mint-/Token-Rechte.
- Portfolio-Breaker: schließt im Paper-Modell nur mit frischen ausführbar modellierbaren Daten.

Keine frischen Preise oder zu hoher Impact: Warnung / Ablehnung statt erfundener Ausführung. Kill Switch friert neue Einstiege und automatische Aktionen ein; manuelle risikoreduzierende Schließungen bleiben unter denselben Daten-/Kostenchecks möglich. Wiederholte Order-Keys liefern dasselbe persistierte Ergebnis; abweichende Aufträge mit gleichem Key werden abgelehnt.

## Bewertung

Keine Optimierung auf diesem kurzen Live-Test. Künftige Kalibrierung benötigt vollständige historische Coverage inklusive gescheiterter/delisteter Tokens, unabhängige Trainings-/Testperioden, Leakage-Prüfung, reale Quote-/Fill-/Failure-Daten und unangetastete OOS-Perioden. Die Replay-CLI implementiert die Ankunftszeitgrenze und chronologische Fenster; sie ersetzt diese Datengrundlage nicht.
