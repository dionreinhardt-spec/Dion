#!/usr/bin/env python3
"""Pin official Pump schemas to a reviewed commit; rerun tests before starting."""
import argparse
import hashlib
import json
import re
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--commit',required=True);args=p.parse_args()
if not re.fullmatch('[0-9a-f]{40}',args.commit):
    raise SystemExit('A full reviewed Git commit SHA is required')
root=Path(__file__).resolve().parents[1]/'backend'/'axiom_intel'/'adapters'
for name in ['pump','pump_amm']:
    url=f'https://raw.githubusercontent.com/pump-fun/pump-public-docs/{args.commit}/idl/{name}.json'
    raw=urllib.request.urlopen(url,timeout=30).read();d=json.loads(raw)
    events=[e for e in d['events'] if any(k in e['name'].lower() for k in ['trade','buy','sell','create','migrat','complete'])]
    out={'address':d['address'],'source':url,'commit':args.commit,'sha256':hashlib.sha256(raw).hexdigest(),
         'retrieved_at':datetime.now(timezone.utc).isoformat(),'events':events,'types':d['types'],
         'instructions':[{'name':i['name'],'discriminator':i['discriminator'],'accounts':i['accounts']} for i in d['instructions']]}
    (root/f'{name}_schema.json').write_text(json.dumps(out,indent=2)+'\n')
    print(name, out['sha256'])
print('Schemas updated. Inspect diffs, verify against confirmed transactions and rerun tests. This does not authorize trading.')
