#!/usr/bin/env python3
"""Create local configuration once. Never prints generated secrets."""
import os
import secrets
from pathlib import Path
root = Path(__file__).resolve().parents[1]
target = root / ".env"
if target.exists():
    raise SystemExit(".env exists; unchanged")
text = (root / ".env.example").read_text()
text = text.replace("replace-with-random-secret", secrets.token_hex(24)).replace("replace-with-random-api-token", secrets.token_urlsafe(32))
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, "w") as f:
    f.write(text)
print(".env created with local random credentials. Configure your RPC provider and open the API-token field in the dashboard.")
