#!/usr/bin/env python3
"""Configure one HTTPS origin; preserve existing API/database secrets. No network IO."""
import argparse
import os
import re
from pathlib import Path


def domain_name(value: str) -> str:
    try:
        value = value.strip().rstrip('.').lower().encode('idna').decode('ascii')
    except UnicodeError:
        raise ValueError('Invalid DNS name') from None
    labels = value.split('.')
    if len(value) > 253 or len(labels) < 2 or not re.search('[a-z]', labels[-1]) or labels[-1] in {'localhost', 'local', 'internal'}:
        raise ValueError('Use a public DNS hostname without scheme, port or path')
    if any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', label) for label in labels):
        raise ValueError('Invalid DNS hostname')
    return value


def configure(env_path: Path, domain: str):
    domain = domain_name(domain)
    if not env_path.is_file():
        raise ValueError('Create .env with scripts/configure.py first, or reuse the existing installation configuration')
    original = env_path.read_text()
    values = {}
    for line in original.splitlines():
        if line.strip() and not line.lstrip().startswith('#') and '=' in line:
            k, v = line.split('=', 1)
            values[k.strip()] = v.strip().strip(chr(34) + chr(39))
    token = values.get('INTEL_API_TOKEN', '')
    if not token or 'replace-with' in token:
        raise ValueError('A real INTEL_API_TOKEN is required before exposing the HTTPS gateway')
    origins = [o.strip() for o in values.get('INTEL_ALLOWED_ORIGINS', '').split(',') if o.strip()]
    origin = 'https://' + domain
    if origin not in origins:
        origins.append(origin)
    kept = [line for line in original.splitlines() if not line.startswith(('INTEL_PUBLIC_DOMAIN=', 'INTEL_ALLOWED_ORIGINS='))]
    content = '\n'.join(kept) + '\nINTEL_PUBLIC_DOMAIN=' + domain + '\nINTEL_ALLOWED_ORIGINS=' + ','.join(origins) + '\n'
    temporary = env_path.with_name(env_path.name + '.iphone-new')
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, 'w') as stream:
            stream.write(content)
        os.replace(temporary, env_path)
    finally:
        if temporary.exists():
            temporary.unlink()
    return origin


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--domain', required=True)
    p.add_argument('--env', type=Path, default=Path(__file__).resolve().parents[1] / '.env')
    args = p.parse_args()
    try:
        origin = configure(args.env, args.domain)
    except ValueError as exc:
        p.error(str(exc))
    print('HTTPS origin configured:', origin)
    print('Existing credentials preserved. DNS, open ports 80/443 and a successful Caddy startup are still required.')

if __name__ == '__main__':
    main()
