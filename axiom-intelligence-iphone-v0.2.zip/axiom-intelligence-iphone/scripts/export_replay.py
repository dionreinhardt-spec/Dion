#!/usr/bin/env python3
"""Export arrival-timed evidence from the configured database to JSONL."""
import argparse
import asyncio
import json
from pathlib import Path
from sqlalchemy import select
from axiom_intel.config import Settings
from axiom_intel.storage import Store, EventRow

async def run(out: Path, since: float):
    s = Store(Settings().database_url.get_secret_value())
    # Export does not start a competing collector or acquire its leadership lock.
    async with s.session() as session:
        rows = await session.scalars(select(EventRow).where(EventRow.kind.in_(["trade", "market", "security", "feed"]), EventRow.timestamp >= since).order_by(EventRow.timestamp))
        out.parent.mkdir(parents=True, exist_ok=True)
        count = 0
        with out.open("w") as f:
            for row in rows:
                payload = row.payload
                at = payload.get("received_at") or payload.get("checked_at") or payload.get("available_at", row.timestamp)
                f.write(json.dumps({"kind": row.kind, "available_at": at, "payload": payload}) + "\n")
                count += 1
    await s.close()
    print(f"Exported {count} recorded inputs to {out}")

if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--out',type=Path,required=True);p.add_argument('--since',type=float,default=0)
    args=p.parse_args();asyncio.run(run(args.out,args.since))
